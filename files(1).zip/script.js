/**
 * CampusCare - Campus Complaint Management System
 * Interactive Dashboard & Analytical Urgency Engine
 * 
 * Features:
 * - Mathematical Urgency Priority Algorithm with tie-breaking
 * - Strict exclusion of Resolved complaints from priority queue
 * - LocalStorage data persistence with auto-unique ID generator (C01, C02, etc.)
 * - Real-time multi-criteria search and filters
 * - Live category progress distribution & interactive SVG trend chart
 * - Dynamic status lifecycle: Raised -> In Progress -> Resolved
 */

// =============================================================================
// 1. CONFIGURATION & WEIGHTS (AS GIVEN IN COMPETITION PROBLEM STATEMENT)
// =============================================================================
const CATEGORY_WEIGHTS = {
  "Wi-Fi": 2,
  "Hostel": 2,
  "Classroom": 1,
  "Laboratory": 3
};

const STORAGE_KEY = "campuscare_complaints_db";

// Initial sample records from the problem statement (built fresh so ages are always correct)
const HOUR = 60 * 60 * 1000;
const FLOW = ["Raised", "In Progress", "Resolved"];
const NEXT_ID_KEY = "campuscare_next_id";

function buildSeed() {
  const now = Date.now();
  const mk = (id, category, description, hoursAgo, status, studentName, location, offsets) => {
    const createdAt = now - hoursAgo * HOUR;
    return {
      id, category, description, createdAt, status, studentName, location,
      statusHistory: FLOW.slice(0, FLOW.indexOf(status) + 1).map((st, k) => ({
        status: st, at: createdAt + (k ? offsets[k - 1] * HOUR : 0)
      }))
    };
  };
  const list = [
    mk("C01", "Wi-Fi", "Internet not working in Lab 2", 48, "Raised", "B. Rajkumar", "Lab 2, CS Block", []),
    mk("C02", "Hostel", "Water pressure problem on 3rd floor Block B", 8, "In Progress", "Dev", "Hostel Block B, Room 304", [3]),
    mk("C03", "Classroom", "Projector not displaying HDMI signal in Room 402", 72, "Raised", "Balu", "Academic Block 1, Room 402", []),
    mk("C04", "Laboratory", "Computer issue: OS corrupted on terminal 14", 24, "Resolved", "Stepen", "Electronics Lab 1", [4, 18])
  ];
  list[3].rating = 4; // sample student feedback (1-5) for the resolved complaint
  return list;
}

// =============================================================================
// 2. STATE MANAGEMENT & LOCAL STORAGE
// =============================================================================
let complaints = [];
let currentFilter = {
  search: "",
  category: "ALL",
  status: "ALL",
  sortBy: "newest"
};

/**
 * Loads complaints from LocalStorage, initializing with PDF standard sample if empty.
 */
function isValidComplaint(c) {
  return c && typeof c === "object" && /^C\d+$/.test(c.id) &&
    Object.prototype.hasOwnProperty.call(CATEGORY_WEIGHTS, c.category) &&
    typeof c.description === "string" && Number.isFinite(c.createdAt) && FLOW.includes(c.status);
}

function loadComplaints() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.every(isValidComplaint)) {
        parsed.forEach(c => {
          if (!(Number.isInteger(c.rating) && c.rating >= 1 && c.rating <= 5)) delete c.rating;
          if (!Array.isArray(c.statusHistory) || !c.statusHistory.length) {
            c.statusHistory = [{ status: c.status, at: c.createdAt }];
          }
        });
        return parsed; // an empty list is valid (user deleted everything)
      }
      console.warn("Stored data was invalid; restoring sample data.");
    }
  } catch (err) {
    console.error("Error reading from LocalStorage:", err);
  }
  const seed = buildSeed();
  saveComplaints(seed);
  try { localStorage.setItem(NEXT_ID_KEY, "5"); } catch (e) {}
  return seed;
}

/**
 * Saves complaints array to LocalStorage.
 */
function saveComplaints(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    console.error("Error saving to LocalStorage:", err);
  }
}

/**
 * Generates next sequential unique ID in the format C01, C02, C03...
 */
function generateNextID(list) {
  const max = (list || []).reduce((m, c) => Math.max(m, parseInt(c.id.slice(1), 10) || 0), 0);
  let stored = 0;
  try { stored = parseInt(localStorage.getItem(NEXT_ID_KEY), 10) || 0; } catch (e) {}
  return "C" + String(Math.max(stored, max + 1)).padStart(2, "0");
}

/** Remember the number so a deleted ID is never handed out again. */
function commitNextID(id) {
  try { localStorage.setItem(NEXT_ID_KEY, String(parseInt(id.slice(1), 10) + 1)); } catch (e) {}
}

// =============================================================================
// 3. ANALYTICAL CHALLENGE: PRIORITY & URGENCY CALCULATION
// Formula: Urgency Score = Category Weight + floor(Hours Pending / 24)
// =============================================================================
function calculateUrgency(complaint) {
  const now = Date.now();
  const diffMs = Math.max(0, now - complaint.createdAt);
  const ageHours = diffMs / (1000 * 60 * 60);
  
  const categoryWeight = CATEGORY_WEIGHTS[complaint.category] ?? 1;
  const ageBonus = Math.floor(ageHours / 24);
  const score = categoryWeight + ageBonus;

  return {
    ...complaint,
    ageHours,
    categoryWeight,
    ageBonus,
    score
  };
}

/**
 * Builds the Top 3 Priority Queue:
 * 1. Excludes Resolved complaints.
 * 2. Maps each to calculateUrgency.
 * 3. Sorts by:
 *    a) Highest urgency score first (b.score - a.score)
 *    b) Older complaint first (b.ageHours - a.ageHours)
 *    c) Higher category weight first
 *    d) Lower ID number first
 * 4. Takes top 3.
 */
function getPriorityQueue(list) {
  return list
    .filter(c => c.status !== "Resolved")
    .map(c => calculateUrgency(c))
    .sort((a, b) => {
      if (b.score !== a.score) {
        return b.score - a.score;
      }
      if (b.ageHours !== a.ageHours) {
        return b.ageHours - a.ageHours;
      }
      if (b.categoryWeight !== a.categoryWeight) {
        return b.categoryWeight - a.categoryWeight;
      }
      return parseInt(a.id.slice(1), 10) - parseInt(b.id.slice(1), 10);
    })
    .slice(0, 3);
}

/**
 * Formats age into human-readable hours / days.
 */
function formatAgeHours(hours) {
  const roundedHours = Math.round(hours);
  if (roundedHours < 1) return "Just now";
  if (roundedHours < 24) return `${roundedHours} hrs ago`;
  const days = Math.floor(roundedHours / 24);
  const remainHours = roundedHours % 24;
  if (remainHours === 0) return `${days}d ago (${roundedHours}h)`;
  return `${days}d ${remainHours}h ago (${roundedHours}h)`;
}

// =============================================================================
// 4. DOM RENDERING: STATS, QUEUE, TABLE & CATEGORY BARS
// =============================================================================

function renderAll() {
  renderSummaryStats();
  renderPriorityQueue();
  renderComplaintsTable();
  renderCategoryBars();
  renderTrendChart();
  updateNextIdPreview();
}

/**
 * Renders Top Summary Metric Cards (Pending, In Progress, Solved, Service Level)
 */
function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function renderSummaryStats() {
  const total = complaints.length;
  const raised = complaints.filter(c => c.status === "Raised").length;
  const inProgress = complaints.filter(c => c.status === "In Progress").length;
  const resolved = complaints.filter(c => c.status === "Resolved").length;
  const pending = raised + inProgress; // Pending = Raised + In Progress

  setText("statPendingCount", pending);
  setText("statInProgressCount", inProgress);
  setText("statResolvedCount", resolved);
  setText("pendingBadge", pending);

  // Badges = each card's real share of ALL complaints
  const share = n => (total > 0 ? Math.round((n / total) * 100) : 0);
  setText("pendingGrowth", `${share(pending)}% of total`);
  setText("progressGrowth", `${share(inProgress)}% of total`);
  setText("solvedGrowth", `${share(resolved)}% of total`);

  // Chart legend (current counts by status)
  setText("legendPending", raised);
  setText("legendProgress", inProgress);
  setText("legendResolved", resolved);

  // Service Level = Resolved / Total * 100 (always real, no fallback)
  const pct = total > 0 ? Math.round((resolved / total) * 1000) / 10 : 0;
  setText("serviceLevelPct", `${pct}%`);
  const circleElem = document.getElementById("serviceLevelCircle");
  if (circleElem) {
    const circumference = 2 * Math.PI * 48;
    circleElem.style.strokeDashoffset = circumference - (pct / 100) * circumference;
  }
  renderFeedback();
}

/** Feedback card = average of the 1-5 ratings given to resolved complaints */
function renderFeedback() {
  const resolvedList = complaints.filter(c => c.status === "Resolved");
  const rated = resolvedList.filter(c => Number.isInteger(c.rating) && c.rating >= 1 && c.rating <= 5);
  const avg = rated.length ? rated.reduce((sum, c) => sum + c.rating, 0) / rated.length : null;
  setText("fbScore", avg === null ? "–" : avg.toFixed(1));
  setText("fbSub", rated.length ? `${rated.length} of ${resolvedList.length} resolved rated` : "No ratings yet");
  const full = avg === null ? 0 : Math.round(avg);
  setText("fbStars", "★".repeat(full) + "☆".repeat(5 - full));
}

function setRating(id, n) {
  const c = complaints.find(x => x.id === id);
  if (!c || c.status !== "Resolved" || !(n >= 1 && n <= 5)) return;
  c.rating = n;
  saveComplaints(complaints);
  renderAll();
  openDetails(id);
  showToast(`Thanks! Rated ${c.id} ${n}/5.`, "success");
}

/**
 * Renders the Top 3 Priority Queue with formula explanations
 */
function renderPriorityQueue() {
  const container = document.getElementById("priorityQueueContainer");
  if (!container) return;

  const top3 = getPriorityQueue(complaints);

  if (top3.length === 0) {
    container.innerHTML = `
      <div class="priority-empty-state">
        <div style="font-size: 2rem; margin-bottom: 8px;">🎉</div>
        <h4>All Urgent Complaints Resolved!</h4>
        <p>No unresolved complaints are currently waiting in the priority queue.</p>
      </div>
    `;
    return;
  }

  const rankClasses = ["rank-1", "rank-2", "rank-3"];
  const rankPillClasses = ["rank-pill-1", "rank-pill-2", "rank-pill-3"];

  container.innerHTML = top3.map((item, index) => {
    let scoreBadgeClass = "score-badge-low";
    if (item.score >= 5) scoreBadgeClass = "score-badge-high";
    else if (item.score >= 3) scoreBadgeClass = "score-badge-medium";

    // Tie breaker reason explanation
    const days = Math.floor(item.ageHours / 24);
    const tieReason = `Weight ${item.categoryWeight} + ${days} day${days === 1 ? "" : "s"} pending = ${item.score}`;

    return `
      <div class="priority-card ${rankClasses[index]}">
        <div class="p-card-top">
          <span class="p-rank-pill ${rankPillClasses[index]}">
            Rank #${index + 1}
          </span>
          <span class="p-score-pill ${scoreBadgeClass}" title="Urgency Score = ${item.categoryWeight} (Category) + ${item.ageBonus} (floor(${Math.round(item.ageHours)}/24))">
            Score: ${item.score}
          </span>
        </div>

        <div class="p-card-body">
          <h4>
            <span>${item.id} &ndash; ${escapeHtml(item.category)}</span>
            <span class="p-cat-tag">Weight: ${item.categoryWeight}</span>
          </h4>
          <p class="p-desc">${escapeHtml(item.description)}</p>
        </div>

        <div class="p-card-meta">
          <span class="p-reason">${tieReason}</span>
          <span class="p-age">${formatAgeHours(item.ageHours)}</span>
        </div>

        <div class="p-card-actions">
          ${item.status === "Raised" ? `
            <button class="btn-p-progress" onclick="updateComplaintStatus('${item.id}', 'In Progress')">
              Start Work
            </button>
          ` : `
            <button class="btn-p-resolve" onclick="updateComplaintStatus('${item.id}', 'Resolved')">
              ✓ Mark Resolved
            </button>
          `}
        </div>
      </div>
    `;
  }).join("");
}

/**
 * Renders the Recent Complaints Table according to active search and filters.
 */
function renderComplaintsTable() {
  const tbody = document.getElementById("complaintsTableBody");
  const emptyState = document.getElementById("tableEmptyState");
  const filterSummary = document.getElementById("tableFilterSummary");
  if (!tbody) return;

  // Apply filters
  let filtered = complaints.map(c => calculateUrgency(c));

  // Search filter (ID, description, category, student, location)
  if (currentFilter.search.trim()) {
    const q = currentFilter.search.trim().toLowerCase();
    filtered = filtered.filter(c => 
      c.id.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q) ||
      c.category.toLowerCase().includes(q) ||
      (c.studentName && c.studentName.toLowerCase().includes(q)) ||
      (c.location && c.location.toLowerCase().includes(q))
    );
  }

  // Category filter
  if (currentFilter.category !== "ALL") {
    filtered = filtered.filter(c => c.category === currentFilter.category);
  }

  // Status filter
  if (currentFilter.status !== "ALL") {
    filtered = filtered.filter(c => c.status === currentFilter.status);
  }

  // Sorting
  switch (currentFilter.sortBy) {
    case "newest":
      filtered.sort((a, b) => b.createdAt - a.createdAt);
      break;
    case "oldest":
      filtered.sort((a, b) => a.createdAt - b.createdAt);
      break;
    case "priority":
      // Unresolved highest score first, then resolved
      filtered.sort((a, b) => {
        if (a.status === "Resolved" && b.status !== "Resolved") return 1;
        if (b.status === "Resolved" && a.status !== "Resolved") return -1;
        return b.score - a.score || b.ageHours - a.ageHours;
      });
      break;
    case "id":
      filtered.sort((a, b) => a.id.localeCompare(b.id));
      break;
  }

  // Update summary caption
  if (filterSummary) {
    filterSummary.textContent = `Showing ${filtered.length} of ${complaints.length} complaints`;
  }

  if (filtered.length === 0) {
    tbody.innerHTML = "";
    if (emptyState) emptyState.style.display = "block";
    return;
  }

  if (emptyState) emptyState.style.display = "none";

  tbody.innerHTML = filtered.map(item => {
    // Category pill class
    let catClass = "cat-wifi";
    if (item.category === "Hostel") catClass = "cat-hostel";
    else if (item.category === "Classroom") catClass = "cat-classroom";
    else if (item.category === "Laboratory") catClass = "cat-lab";

    // Status pill style matching screenshot
    let statusBadgeClass = "badge-status-raised";
    let statusLabel = item.status;
    if (item.status === "In Progress") {
      statusBadgeClass = "badge-status-progress";
    } else if (item.status === "Resolved") {
      statusBadgeClass = "badge-status-resolved";
    }

    // Urgency score pill
    let scoreBadgeClass = "score-badge-low";
    if (item.score >= 5) scoreBadgeClass = "score-badge-high";
    else if (item.score >= 3) scoreBadgeClass = "score-badge-medium";

    return `
      <tr id="row-${item.id}">
        <td class="td-id">${item.id}</td>
        <td class="td-date">${formatAgeHours(item.ageHours)}</td>
        <td>
          <div class="td-student-meta">
            <span class="td-name">${escapeHtml(item.studentName || 'Student')}</span>
            <span class="td-location">${escapeHtml(item.location || 'Campus')}</span>
          </div>
        </td>
        <td>
          <span class="td-category-tag ${catClass}">
            ${escapeHtml(item.category)}
          </span>
        </td>
        <td>
          <div class="td-desc" title="${escapeHtml(item.description)}">
            ${escapeHtml(item.description)}
          </div>
        </td>
        <td>
          ${item.status === "Resolved" ? `
            <span class="p-cat-tag" title="Excluded from queue because Resolved">Resolved</span>
          ` : `
            <span class="td-urgency-badge ${scoreBadgeClass}" title="Category Weight: ${item.categoryWeight} + floor(${Math.round(item.ageHours)}/24) = ${item.score}">
              Score: ${item.score}
            </span>
          `}
        </td>
        <td>
          <span class="badge-status ${statusBadgeClass}">
            ${statusLabel}
          </span>
        </td>
        <td class="text-right">
          <div class="table-actions-cell">
            ${item.status === "Resolved"
              ? `<button class="btn-status-change" disabled title="Resolved complaints are locked">🔒 Resolved</button>`
              : `<button class="btn-status-change" onclick="advanceStatus('${item.id}')">${item.status === "Raised" ? "Start work" : "Mark resolved"}</button>`}
            <button class="btn-status-change" onclick="openDetails('${item.id}')" title="View details and status history">Details</button>

            <button class="btn-action-icon btn-delete-row" onclick="deleteComplaint('${item.id}')" title="Delete complaint">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="3 6 5 6 21 6"/>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
              </svg>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join("");
}

/**
 * Renders the Right Column Category Distribution Progress Bars
 */
function renderCategoryBars() {
  const total = complaints.length;
  const categories = ["Wi-Fi", "Hostel", "Classroom", "Laboratory"];
  const ids = {
    "Wi-Fi": { pct: "catPctWifi", bar: "catBarWifi", count: "catCountWifi", pending: "catPendingWifi" },
    "Hostel": { pct: "catPctHostel", bar: "catBarHostel", count: "catCountHostel", pending: "catPendingHostel" },
    "Classroom": { pct: "catPctClassroom", bar: "catBarClassroom", count: "catCountClassroom", pending: "catPendingClassroom" },
    "Laboratory": { pct: "catPctLab", bar: "catBarLab", count: "catCountLab", pending: "catPendingLab" }
  };

  categories.forEach(cat => {
    const catComplaints = complaints.filter(c => c.category === cat);
    const count = catComplaints.length;
    const pendingCount = catComplaints.filter(c => c.status !== "Resolved").length;
    const pct = total > 0 ? Math.round((count / total) * 100) : 0;

    const el = ids[cat];
    if (el) {
      const pctEl = document.getElementById(el.pct);
      const barEl = document.getElementById(el.bar);
      const countEl = document.getElementById(el.count);
      const pendingEl = document.getElementById(el.pending);

      if (pctEl) pctEl.textContent = `${pct}%`;
      if (barEl) barEl.style.width = `${pct}%`;
      if (countEl) countEl.textContent = `${count} ${count === 1 ? 'complaint' : 'complaints'}`;
      if (pendingEl) pendingEl.textContent = `${pendingCount} pending`;
    }
  });

  // Footer summary
  const totalVolumeEl = document.getElementById("catTotalVolume");
  const pendingVolumeEl = document.getElementById("catPendingVolume");
  const resolveRateEl = document.getElementById("catResolveRate");

  const totalPending = complaints.filter(c => c.status !== "Resolved").length;
  const totalResolved = complaints.filter(c => c.status === "Resolved").length;
  const resolveRate = total > 0 ? Math.round((totalResolved / total) * 100) : 0;

  if (totalVolumeEl) totalVolumeEl.textContent = total;
  if (pendingVolumeEl) pendingVolumeEl.textContent = totalPending;
  if (resolveRateEl) resolveRateEl.textContent = `${resolveRate}%`;
}

/**
 * Updates next ID preview in the complaint submission form
 */
function updateNextIdPreview() {
  const preview = document.getElementById("nextIdPreview");
  if (preview) {
    preview.textContent = generateNextID(complaints);
  }
}

// =============================================================================
// 5. STATUS LIFECYCLE MANAGEMENT (RAISED -> IN PROGRESS -> RESOLVED)
// =============================================================================
function toggleStatusDropdown(id) {
  // Close any open status popups first
  document.querySelectorAll(".status-menu-popup.active").forEach(el => {
    if (el.id !== `status-popup-${id}`) el.classList.remove("active");
  });
  const popup = document.getElementById(`status-popup-${id}`);
  if (popup) popup.classList.toggle("active");
}

// Close popups on outside click
document.addEventListener("click", (e) => {
  if (!e.target.closest(".status-dropdown-wrap")) {
    document.querySelectorAll(".status-menu-popup.active").forEach(el => {
      el.classList.remove("active");
    });
  }
});

function updateComplaintStatus(id, newStatus) {
  const complaint = complaints.find(c => c.id === id);
  if (!complaint) return;

  // Strict flow: only the immediate next step is allowed
  const idx = FLOW.indexOf(complaint.status);
  if (idx < 0 || idx >= FLOW.length - 1 || FLOW[idx + 1] !== newStatus) return;

  complaint.status = newStatus;
  if (!Array.isArray(complaint.statusHistory)) complaint.statusHistory = [];
  complaint.statusHistory.push({ status: newStatus, at: Date.now() });
  if (newStatus === "Resolved") {
    complaint.resolvedAt = Date.now();
  } else {
    delete complaint.resolvedAt;
  }

  saveComplaints(complaints);
  renderAll();

  // Toast feedback
  if (newStatus === "Resolved") {
    showToast(`Complaint ${id} has been successfully resolved! (Removed from priority queue)`, "success");
  } else {
    showToast(`Complaint ${id} status updated to ${newStatus}.`, "info");
  }
}

function advanceStatus(id) {
  const c = complaints.find(x => x.id === id);
  if (!c) return;
  const next = FLOW[FLOW.indexOf(c.status) + 1];
  if (next) updateComplaintStatus(id, next);
}

function fmtDateTime(t) {
  return new Date(t).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
}

/** Details modal with full status history (built with textContent, XSS-safe) */
function openDetails(id) {
  const c = complaints.find(x => x.id === id);
  const body = document.getElementById("detailsBody");
  if (!c || !body) return;
  const u = calculateUrgency(c);
  body.textContent = "";
  const add = (tag, text, cls) => { const e = document.createElement(tag); e.textContent = text; if (cls) e.className = cls; body.appendChild(e); return e; };
  add("h4", `${c.id} · ${c.category} · ${c.status}`);
  add("p", c.description, "details-desc");
  add("p", `Reported by ${c.studentName || "Student"} at ${c.location || "Campus"} on ${fmtDateTime(c.createdAt)} (${formatAgeHours(u.ageHours)})`, "details-meta");
  add("p", c.status === "Resolved" ? "Urgency: not scored (resolved)" : `Urgency: weight ${u.categoryWeight} + ${u.ageBonus} day(s) = ${u.score}`, "details-meta");
  if (c.status === "Resolved") {
    add("h4", "Rate this resolution");
    const row = document.createElement("div"); row.className = "rate-row";
    for (let i = 1; i <= 5; i++) {
      const b = document.createElement("button"); b.type = "button";
      b.textContent = i <= (c.rating || 0) ? "★" : "☆";
      b.setAttribute("aria-label", `Rate ${i} out of 5`);
      b.addEventListener("click", () => setRating(c.id, i));
      row.appendChild(b);
    }
    body.appendChild(row);
  }
  add("h4", "Status history");
  const ul = document.createElement("ul"); ul.className = "details-history";
  (c.statusHistory || []).forEach(hh => { const li = document.createElement("li"); li.textContent = `${hh.status} — ${fmtDateTime(hh.at)}`; ul.appendChild(li); });
  body.appendChild(ul);
  openModal("detailsModal");
}

function deleteComplaint(id) {
  if (!confirm(`Are you sure you want to delete complaint ${id}?`)) return;
  complaints = complaints.filter(c => c.id !== id);
  saveComplaints(complaints);
  renderAll();
  showToast(`Complaint ${id} deleted.`, "info");
}

// =============================================================================
// 6. COMPLAINT SUBMISSION FORM & VALIDATION
// =============================================================================
/** Pure validator: trims, requires category, 10-300 chars. */
function validateComplaint(input) {
  const category = String((input && input.category) || "");
  const description = String((input && input.description) || "").trim();
  const errors = {};
  if (!Object.prototype.hasOwnProperty.call(CATEGORY_WEIGHTS, category)) errors.category = "Please select a category.";
  if (!description) errors.description = "Description is required.";
  else if (description.length < 10) errors.description = `Too short: add ${10 - description.length} more character(s) (minimum 10).`;
  else if (description.length > 300) errors.description = `Too long: remove ${description.length - 300} character(s) (maximum 300).`;
  return { ok: Object.keys(errors).length === 0, errors, clean: { category, description } };
}

function setFieldError(inputId, errId, msg) {
  const el = document.getElementById(errId), inp = document.getElementById(inputId);
  if (el) el.textContent = msg || "";
  if (inp) { inp.classList.toggle("input-invalid", !!msg); inp.setAttribute("aria-invalid", msg ? "true" : "false"); }
}

let submitLock = false;

function initComplaintForm() {
  const form = document.getElementById("complaintForm");
  const formCategory = document.getElementById("formCategory");
  const formDescription = document.getElementById("formDescription");
  const formStudentName = document.getElementById("formStudentName");
  const formLocation = document.getElementById("formLocation");
  const formSimulatedHours = document.getElementById("formSimulatedHours");
  const formAlert = document.getElementById("formAlert");
  const charCount = document.getElementById("charCount");

  if (formDescription && charCount) {
    formDescription.addEventListener("input", () => {
      const n = formDescription.value.trim().length;
      charCount.textContent = `${n} / 300`;
      charCount.classList.toggle("char-bad", n > 300 || (n > 0 && n < 10));
    });
  }

  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();

      // Clear alert
      if (formAlert) {
        formAlert.style.display = "none";
        formAlert.className = "form-alert";
      }

      if (submitLock) return;
      const v = validateComplaint({ category: formCategory.value, description: formDescription.value });
      const studentName = formStudentName.value.trim().slice(0, 60) || "Student";
      const location = formLocation.value.trim().slice(0, 60) || "Campus";
      const simHours = Math.min(720, Math.max(0, parseFloat(formSimulatedHours.value) || 0));

      // Duplicate guard: same category + text within 10 seconds
      const dup = v.ok && complaints.some(x => x.category === v.clean.category && x.description === v.clean.description && Date.now() - x.createdAt < 10000);
      if (dup) v.errors.description = "This looks like a duplicate of a complaint you just submitted.";

      setFieldError("formCategory", "errCategory", v.errors.category);
      setFieldError("formDescription", "errDescription", v.errors.description);
      if (!v.ok || dup) {
        (v.errors.category ? formCategory : formDescription).focus();
        return;
      }
      const category = v.clean.category, description = v.clean.description;
      submitLock = true;
      const submitBtn = document.getElementById("submitFormBtn");
      if (submitBtn) submitBtn.disabled = true;
      setTimeout(() => { submitLock = false; if (submitBtn) submitBtn.disabled = false; }, 800);

      // Generate next unique ID
      const newId = generateNextID(complaints);
      commitNextID(newId);

      // Calculate createdAt (allows simulating past hours if specified)
      const createdAt = simHours > 0 ? Date.now() - (simHours * 60 * 60 * 1000) : Date.now();

      const newComplaint = {
        id: newId,
        category,
        description,
        createdAt,
        status: "Raised",
        studentName,
        location,
        statusHistory: [{ status: "Raised", at: createdAt }]
      };

      complaints.unshift(newComplaint);
      saveComplaints(complaints);
      renderAll();

      // Close modal
      closeModal("submitModal");
      form.reset();
      if (charCount) { charCount.textContent = "0 / 300"; charCount.classList.remove("char-bad"); }
      setFieldError("formCategory", "errCategory", "");
      setFieldError("formDescription", "errDescription", "");

      // Show success toast
      showToast(`Complaint submitted successfully! Your Complaint ID is ${newId}.`, "success");
    });
  }
}

function showFormAlert(message, type) {
  const alert = document.getElementById("formAlert");
  if (!alert) return;
  alert.textContent = message;
  alert.className = `form-alert alert-${type}`;
  alert.style.display = "block";
}

// =============================================================================
// 7. SEARCH & FILTER EVENT LISTENERS
// =============================================================================
function initFilters() {
  const globalSearch = document.getElementById("globalSearchInput");
  const searchClear = document.getElementById("searchClearBtn");
  const categoryFilter = document.getElementById("categoryFilter");
  const statusFilter = document.getElementById("statusFilter");
  const sortBySelect = document.getElementById("sortBySelect");
  const resetFiltersBtn = document.getElementById("resetFiltersBtn");
  const clearFilterBtn = document.getElementById("clearFilterBtn");
  const filterToggleBtn = document.getElementById("filterToggleBtn");
  const filterToolbar = document.getElementById("filterToolbar");

  if (globalSearch) {
    globalSearch.addEventListener("input", (e) => {
      currentFilter.search = e.target.value;
      if (searchClear) {
        searchClear.style.display = currentFilter.search ? "block" : "none";
      }
      renderComplaintsTable();
    });
  }

  if (searchClear) {
    searchClear.addEventListener("click", () => {
      if (globalSearch) globalSearch.value = "";
      currentFilter.search = "";
      searchClear.style.display = "none";
      renderComplaintsTable();
    });
  }

  if (categoryFilter) {
    categoryFilter.addEventListener("change", (e) => {
      currentFilter.category = e.target.value;
      renderComplaintsTable();
    });
  }

  if (statusFilter) {
    statusFilter.addEventListener("change", (e) => {
      currentFilter.status = e.target.value;
      renderComplaintsTable();
    });
  }

  if (sortBySelect) {
    sortBySelect.addEventListener("change", (e) => {
      currentFilter.sortBy = e.target.value;
      renderComplaintsTable();
    });
  }

  function resetAllFilters() {
    currentFilter = {
      search: "",
      category: "ALL",
      status: "ALL",
      sortBy: "newest"
    };
    if (globalSearch) globalSearch.value = "";
    if (searchClear) searchClear.style.display = "none";
    if (categoryFilter) categoryFilter.value = "ALL";
    if (statusFilter) statusFilter.value = "ALL";
    if (sortBySelect) sortBySelect.value = "newest";
    renderComplaintsTable();
    showToast("Filters reset to default view.", "info");
  }

  if (resetFiltersBtn) resetFiltersBtn.addEventListener("click", resetAllFilters);
  if (clearFilterBtn) clearFilterBtn.addEventListener("click", resetAllFilters);

  if (filterToggleBtn && filterToolbar) {
    filterToggleBtn.addEventListener("click", () => {
      filterToolbar.classList.toggle("collapsed");
    });
  }
}

// =============================================================================
// 8. MODAL DIALOGS CONTROLLER
// =============================================================================
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add("active");
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove("active");
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }
}

function initModals() {
  // Open buttons
  const openSubmitBtn = document.getElementById("openSubmitModalBtn");
  const headerNewBtn = document.getElementById("headerNewComplaintBtn");
  const openFormulaBtn = document.getElementById("openFormulaModalBtn");
  const topSettingsBtn = document.getElementById("topSettingsBtn");
  const openSettingsBtn = document.getElementById("openSettingsModalBtn");
  const openFaqBtn = document.getElementById("openFaqModalBtn");

  if (openSubmitBtn) openSubmitBtn.addEventListener("click", () => { updateNextIdPreview(); openModal("submitModal"); });
  if (headerNewBtn) headerNewBtn.addEventListener("click", () => { updateNextIdPreview(); openModal("submitModal"); });
  if (openFormulaBtn) openFormulaBtn.addEventListener("click", () => openModal("formulaModal"));
  if (topSettingsBtn) topSettingsBtn.addEventListener("click", () => openModal("formulaModal"));
  if (openSettingsBtn) openSettingsBtn.addEventListener("click", () => openModal("formulaModal"));
  if (openFaqBtn) openFaqBtn.addEventListener("click", () => openModal("faqModal"));

  // Close buttons
  const closeSubmitBtn = document.getElementById("closeSubmitModalBtn");
  const cancelSubmitBtn = document.getElementById("cancelSubmitBtn");
  const closeFormulaBtn = document.getElementById("closeFormulaModalBtn");
  const closeFormulaBtn2 = document.getElementById("closeFormulaModalBtn2");
  const closeFaqBtn = document.getElementById("closeFaqModalBtn");
  const closeFaqBtn2 = document.getElementById("closeFaqModalBtn2");

  if (closeSubmitBtn) closeSubmitBtn.addEventListener("click", () => closeModal("submitModal"));
  if (cancelSubmitBtn) cancelSubmitBtn.addEventListener("click", () => closeModal("submitModal"));
  if (closeFormulaBtn) closeFormulaBtn.addEventListener("click", () => closeModal("formulaModal"));
  if (closeFormulaBtn2) closeFormulaBtn2.addEventListener("click", () => closeModal("formulaModal"));
  const closeDetailsBtn = document.getElementById("closeDetailsModalBtn");
  if (closeDetailsBtn) closeDetailsBtn.addEventListener("click", () => closeModal("detailsModal"));
  if (closeFaqBtn) closeFaqBtn.addEventListener("click", () => closeModal("faqModal"));
  if (closeFaqBtn2) closeFaqBtn2.addEventListener("click", () => closeModal("faqModal"));

  // Outside click & Escape key
  document.querySelectorAll(".modal-overlay").forEach(overlay => {
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) {
        closeModal(overlay.id);
      }
    });
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      document.querySelectorAll(".modal-overlay.active").forEach(m => closeModal(m.id));
    }
  });

  // Mobile menu toggle
  const mobileBtn = document.getElementById("mobileMenuBtn");
  const sidebar = document.getElementById("sidebar");
  if (mobileBtn && sidebar) {
    mobileBtn.addEventListener("click", () => {
      sidebar.classList.toggle("mobile-open");
    });
  }
}

// =============================================================================
// 9. INTERACTIVE URGENCY FORMULA TESTER
// =============================================================================
function initFormulaTester() {
  const catInput = document.getElementById("testCategory");
  const hoursInput = document.getElementById("testHours");
  const scoreOut = document.getElementById("testScoreOutput");
  const breakdownOut = document.getElementById("testBreakdownOutput");

  function recalculate() {
    if (!catInput || !hoursInput || !scoreOut) return;
    const cat = catInput.value;
    const hours = Math.max(0, parseFloat(hoursInput.value) || 0);
    const weight = CATEGORY_WEIGHTS[cat] ?? 1;
    const bonus = Math.floor(hours / 24);
    const score = weight + bonus;

    scoreOut.textContent = score;
    if (breakdownOut) {
      breakdownOut.textContent = `${weight} (Weight) + floor(${hours} / 24) = ${weight} + ${bonus} = ${score}`;
    }
  }

  if (catInput) catInput.addEventListener("change", recalculate);
  if (hoursInput) hoursInput.addEventListener("input", recalculate);
  recalculate();
}

// =============================================================================
// 10. INTERACTIVE SVG TREND LINE CHART
// =============================================================================
let chartData = null;
const SVGNS = "http://www.w3.org/2000/svg";

/** Status a complaint had at time t (reconstructed from its status history); null if not yet created. */
function statusAt(c, t) {
  if (c.createdAt > t) return null;
  let st = FLOW[0];
  (c.statusHistory || []).forEach(hh => { if (hh.at <= t) st = hh.status; });
  return st;
}

/** Builds the line chart from REAL data: complaints per status at the end of each of the last 7 days. */
function renderTrendChart() {
  const grid = document.getElementById("chartGrid");
  if (!grid) return;
  const now = Date.now();
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    const end = i === 0 ? now : new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999).getTime();
    days.push({ t: end, label: d.toLocaleDateString([], { month: "short", day: "2-digit" }) });
  }
  const counts = days.map(day => {
    const n = { Raised: 0, "In Progress": 0, Resolved: 0 };
    complaints.forEach(c => { const st = statusAt(c, day.t); if (st) n[st]++; });
    return n;
  });
  const series = [
    { vals: counts.map(n => n.Raised), line: "curveLineRaised", el: "curveLinePending", area: "curveAreaPending", color: "#1b60e8" },
    { vals: counts.map(n => n["In Progress"]), el: "curveLineProgress", area: "curveAreaProgress", color: "#00b4d8" },
    { vals: counts.map(n => n.Resolved), el: "curveLineResolved", area: null, color: "#10b981" }
  ];
  const maxVal = Math.max(1, ...series.flatMap(x => x.vals));
  const step = Math.max(1, Math.ceil(maxVal / 4)), yMax = step * 4;
  const X0 = 80, X1 = 860, xs = days.map((_, i) => X0 + i * (X1 - X0) / 6);
  const yFor = v => 200 - (v / yMax) * 160;
  const mk = (tag, attrs, text) => { const e = document.createElementNS(SVGNS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); if (text !== undefined) e.textContent = text; return e; };

  grid.textContent = "";
  for (let k = 0; k <= 4; k++) {
    const y = yFor(k * step);
    grid.appendChild(mk("line", { x1: 60, y1: y, x2: 880, y2: y, class: "chart-grid-line" + (k === 0 ? " axis-line" : "") }));
    grid.appendChild(mk("text", { x: 45, y: y + 4, class: "chart-axis-label", "text-anchor": "end" }, k * step));
  }
  const xl = document.getElementById("chartXLabels"); xl.textContent = "";
  days.forEach((d, i) => xl.appendChild(mk("text", { x: xs[i], y: 222, class: "chart-axis-label", "text-anchor": "middle" }, d.label)));

  const dots = document.getElementById("chartDots"); dots.textContent = "";
  series.forEach(sr => {
    const d = sr.vals.map((v, i) => `${i ? "L" : "M"} ${xs[i]},${yFor(v)}`).join(" ");
    document.getElementById(sr.el).setAttribute("d", d);
    if (sr.area) document.getElementById(sr.area).setAttribute("d", `${d} L ${X1},200 L ${X0},200 Z`);
    sr.vals.forEach((v, i) => dots.appendChild(mk("circle", { cx: xs[i], cy: yFor(v), r: 3.5, fill: sr.color })));
  });

  const first = days[0].label, last = days[6].label;
  setText("chartDateRange", `${first} - ${last}`);
  const prevIdx = chartData ? chartData.idx : 6;
  chartData = { xs, days, series, yFor, idx: prevIdx };
  showChartPoint(prevIdx);
}

function showChartPoint(i) {
  if (!chartData) return;
  const { xs, days, series, yFor } = chartData;
  chartData.idx = i;
  const g = document.getElementById("chartHoverGroup");
  if (g) g.style.display = "block";
  const line = document.getElementById("hoverVerticalLine");
  if (line) { line.setAttribute("x1", xs[i]); line.setAttribute("x2", xs[i]); }
  ["hoverPointPending", "hoverPointProgress", "hoverPointResolved"].forEach((id, k) => {
    const p = document.getElementById(id);
    if (p) { p.setAttribute("cx", xs[i]); p.setAttribute("cy", yFor(series[k].vals[i])); }
  });
  setText("ttDate", days[i].label);
  setText("ttPendingVal", series[0].vals[i]);
  setText("ttProgressVal", series[1].vals[i]);
  setText("ttResolvedVal", series[2].vals[i]);
  const badge = document.getElementById("chartTooltipBadge");
  if (badge) {
    badge.style.right = "auto";
    badge.style.transform = "translateX(-50%)";
    badge.style.left = Math.min(85, Math.max(15, xs[i] / 900 * 100)) + "%";
  }
}

function initTrendChart() {
  const svg = document.getElementById("trendSvg");
  if (!svg) return;
  svg.addEventListener("mousemove", (e) => {
    if (!chartData) return;
    const r = svg.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width * 900;
    let best = 0;
    chartData.xs.forEach((px, i) => { if (Math.abs(px - x) < Math.abs(chartData.xs[best] - x)) best = i; });
    if (best !== chartData.idx) showChartPoint(best);
  });
  svg.addEventListener("mouseleave", () => showChartPoint(6));
}

// =============================================================================
// 11. EXTRA EVALUATION FEATURES: EXPORT CSV & RESET SAMPLE DATA
// =============================================================================
function initExportCsv() {
  const exportBtn = document.getElementById("exportCsvBtn");
  if (!exportBtn) return;

  exportBtn.addEventListener("click", () => {
    if (complaints.length === 0) {
      showToast("No complaints to export.", "info");
      return;
    }

    const headers = ["ID", "Category", "Description", "Student", "Location", "Status", "Age (Hours)", "Urgency Score", "Submitted At"];
    const rows = complaints.map(c => {
      const u = calculateUrgency(c);
      return [
        `"${u.id}"`,
        `"${u.category}"`,
        `"${u.description.replace(/"/g, '""')}"`,
        `"${(u.studentName || '').replace(/"/g, '""')}"`,
        `"${(u.location || '').replace(/"/g, '""')}"`,
        `"${u.status}"`,
        Math.round(u.ageHours),
        u.score,
        `"${new Date(u.createdAt).toISOString()}"`
      ].join(",");
    });

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `campuscare_complaints_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    showToast("Complaint records exported to CSV successfully!", "success");
  });
}

function initResetData() {
  const resetBtn = document.getElementById("resetDataBtn");
  if (!resetBtn) return;

  resetBtn.addEventListener("click", () => {
    if (confirm("Reset complaints database to the initial PDF dataset (C01 to C04)?")) {
      complaints = buildSeed();
      try { localStorage.setItem(NEXT_ID_KEY, "5"); } catch (e) {}
      saveComplaints(complaints);
      renderAll();
      showToast("Reset to initial PDF competition dataset (C01-C04)!", "success");
    }
  });
}

// =============================================================================
// 12. TOAST NOTIFICATION UTILITY
// =============================================================================
function showToast(message, type = "info") {
  const container = document.getElementById("toastContainer");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span class="toast-msg">${escapeHtml(message)}</span>
    <button class="toast-close" aria-label="Close notification">&times;</button>
  `;

  const closeBtn = toast.querySelector(".toast-close");
  closeBtn.addEventListener("click", () => toast.remove());

  container.appendChild(toast);

  // Auto remove after 4 seconds
  setTimeout(() => {
    if (toast.parentElement) toast.remove();
  }, 4000);
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// =============================================================================
// 13. APP BOOTSTRAP
// =============================================================================
document.addEventListener("DOMContentLoaded", () => {
  complaints = loadComplaints();
  renderAll();
  initComplaintForm();
  initFilters();
  initModals();
  initFormulaTester();
  initTrendChart();
  initExportCsv();
  initResetData();

  // Live refresh: ages and urgency scores recalculate every minute
  setInterval(renderAll, 60 * 1000);
});
